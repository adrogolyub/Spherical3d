#ifndef UTILS
#define UTILS

namespace vutils
{
    void
}

#endif // UTILS

